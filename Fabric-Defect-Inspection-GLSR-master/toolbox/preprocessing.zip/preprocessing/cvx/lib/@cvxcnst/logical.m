function x = logical( v ) %#ok
error( 'Disciplined convex programming error:\n   Constraints may not appear in if/then statements.', 1 ); %#ok
