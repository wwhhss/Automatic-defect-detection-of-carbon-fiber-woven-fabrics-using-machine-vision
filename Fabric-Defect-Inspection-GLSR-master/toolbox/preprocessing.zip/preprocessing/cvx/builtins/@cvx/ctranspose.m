function y = ctranspose( x )

%Disciplined convex/geometric programming information for CTRANSPOSE (.):
%   The complex conjugate transpose operation may be applied to CVX
%   variables without restriction.

%
% Determine permutation
%

s = x.size_;
if length( s ) > 2,
    error( 'Transpose of an ND array is not defined.' );
end

%
% Permute the data
%

ndxs = 1 : prod( s );
ndx2 = reshape( ndxs, s ).';
b = conj( x.basis_ );
try
    b = b( :, ndx2 );
catch
    ndxs( ndx2( : ).' ) = ndxs;
    [ r, c, v ] = find( b );
    b = sparse( r, ndxs( c ), v, size( b, 1 ), size( b, 2 ) );
    clear r c v
end
y = cvx( size( ndx2 ), b );

% Copyright 2010 Michael C. Grant and Stephen P. Boyd.
% See the file COPYING.txt for full copyright information.
% The command 'cvx_where' will show where this file is located.
