clear ; clc ; close all;

imName = 'AD0.jpg';

patch_id = compute_SLIC_patch(imName , 20 , 120);

